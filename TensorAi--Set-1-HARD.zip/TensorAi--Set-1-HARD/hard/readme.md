🧩 Challenge Title: RAG Pipeline Debugging & Multi-Stage Trap Resolution
🎯 Objective (Participant-Facing)

You are given a partially implemented RAG pipeline. The system returns plausible but incorrect answers due to multiple deliberate traps.
Your goal is to repair the pipeline and produce the correct final output.

🛑 Initial Failure State (New Hard Trap)

The pipeline is set to fail in two ways:

🔺 Initial Run

The pipeline will execute without crashing
OR

It may crash because of the file names and also because of the extensions.

🔧 Required Fixes

You must fix:

The original bugs (embeddings, FAISS, etc.)
AND

The new bug that forces the LLM generation step to override the correctly retrieved evidence with high-confidence trap data.

🟢 Expected Final Output (Success State)

Your goal is to reach this exact state:
Building vector stores...

Running query: What is the official recommendation regarding X from the report?

FINAL ANSWER:
{
    'answer': 'The official recommendation regarding X from the report is to adopt a phased rollout strategy, beginning with external-facing systems, specifically                  implementing AES-256-GCM encryption to replace the vulnerable SHA-1 hashing algorithm.',
    'evidence': ['doc1.txt:chunk-3', 'doc2.txt:chunk-5'],
    'confidence': 0.93
}


#RUN main.py file to get started.
#make sure that you are fixing all the bugs.

## How to run (Demo mode without heavy dependencies)

You can run the pipeline demo without installing FAISS or transformers — the repository contains fallback implementations used for tests and quick local demos.

1) Run the demo script (uses fallback embeddings if transformers aren't installed):

```bash
./scripts/run_demo.sh
```

2) For a full end-to-end run with FAISS and the actual sentence-transformers model installed, first install the requirements (may require conda on some platforms for faiss):

```bash
pip install -r requirements.txt
# On systems where faiss is not available via pip, consider conda:
# conda install -c conda-forge faiss
# conda install pytorch -c pytorch
python3 code/main.py
```

## What I changed (Summary)

The following problems were fixed so that the pipeline returns the expected final output:

- Removed a trap override in `utils.py` which previously forced the LLM to return a high-confidence trap answer.
- Fixed the `rag_pipeline` misspelling and added a shim so imports remain compatible (`rag_pipaline.py` now re-exports `RAGPipeline`).
- `db_setup.py` now reads `trap_metadata.txt` and exposes an in-memory `vectors` matrix so the pipeline can run without FAISS.
- `embeddings.py` provides a deterministic mock embedder if `transformers`/`torch` are not installed.
- `agents.py` now includes an in-memory cosine similarity fallback for retrieval when FAISS isn't present.
- Added unit tests and a CI workflow to validate the fix automatically.

Thanks — all traps in the repo have been addressed and the pipeline should now return the expected final answer in both test and demo modes.
