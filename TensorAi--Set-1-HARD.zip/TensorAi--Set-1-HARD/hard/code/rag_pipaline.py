"""
Compatibility shim: `rag_pipaline.py` was the misspelled file name that referenced a buggy pipeline.
This file now imports and re-exports the corrected pipeline to preserve import compatibility.
"""

from .rag_pipeline import RAGPipeline  # noqa: E402,F401
