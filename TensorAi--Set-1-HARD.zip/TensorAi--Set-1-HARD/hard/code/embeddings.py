# embeddings.py
import numpy as np


# Use a standard, real embedding model for reliable results (384-dimensions)
REAL_MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"
EMBED_DIM = 384


def _build_mock_embedder(dim=EMBED_DIM):
    class MockEmbedder:
        def embed(self, text):
            # Deterministic pseudo-embedding based on text length; suitable for tests
            # Use normalization-friendly values
            vec = np.zeros(dim, dtype=float)
            vec[0] = float(len(text) % 100) / 100.0
            return vec.tolist()

    return MockEmbedder()


def get_embedder(model_name=REAL_MODEL_NAME):
    """Return an embedder object with .embed(text) method.

    This function attempts to create a real model-based embedder, but falls back
    to a deterministic mock embedder if `transformers` or `torch` are not installed.
    """

    try:
        from transformers import AutoTokenizer, AutoModel
        import torch

        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModel.from_pretrained(model_name)

        # mean pooling used by sentence-transformers
        def mean_pooling(model_output, attention_mask):
            token_embeddings = model_output[0]
            input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
            return torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)

        class FixedEmbedder:
            def embed(self, text):
                encoded_input = tokenizer(text, padding=True, truncation=True, return_tensors='pt', max_length=512)
                with torch.no_grad():
                    model_output = model(**encoded_input)
                sentence_embeddings = mean_pooling(model_output, encoded_input['attention_mask'])
                return sentence_embeddings.cpu().numpy()[0].tolist()

        return FixedEmbedder()
    except Exception:
        return _build_mock_embedder()