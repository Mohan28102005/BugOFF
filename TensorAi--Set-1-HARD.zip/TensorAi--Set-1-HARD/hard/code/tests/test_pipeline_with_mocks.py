import asyncio
import os
from rag_pipeline import RAGPipeline


async def test_pipeline_with_mocked_retrieval_and_validation():
    # Arrange: create minimal dbs structure used by the pipeline (indexes unused by mocked retriever)
    dbs = {
        "correct": {"index": None, "meta": [("doc1.txt:chunk-3", "..."), ("doc2.txt:chunk-5", "...")]},
        "trap": {"index": None, "meta": []}
    }

    config_path = os.path.join(os.path.dirname(__file__), '..', 'mcp_config.json')
    pipeline = RAGPipeline(dbs=dbs, mcp_config_path=config_path)

    # Monkeypatch retriever and validator to avoid using external dependencies
    async def fake_retrieve(query, k=5):
        return [("doc1.txt:chunk-3", "...text...", 0.96), ("doc2.txt:chunk-5", "...text...", 0.90)]

    async def fake_validate(query):
        return True

    pipeline.retriever.retrieve = fake_retrieve
    pipeline.validator.validate = fake_validate

    # Act
    resp = await pipeline.run_async("What is the official recommendation regarding X from the report?")

    # Assert
    assert isinstance(resp, dict)
    assert 'answer' in resp and 'evidence' in resp and 'confidence' in resp
    assert 'phased rollout strategy' in resp['answer']
    assert resp['evidence'] == ["doc1.txt:chunk-3", "doc2.txt:chunk-5"]
    assert abs(resp['confidence'] - 0.93) < 1e-6


def run():
    asyncio.run(test_pipeline_with_mocked_retrieval_and_validation())
    print('test_pipeline_with_mocks passed')

if __name__ == '__main__':
    run()
