from utils import generate_llm_response


def test_generate_llm_response_returns_expected():
    # Arrange: some retrieved data (meta_name, chunk_text, score)
    retrieved = [
        ("doc1.txt:chunk-3", "...text of chunk 3 from doc1...", 0.96),
        ("doc2.txt:chunk-5", "...text of chunk 5 from doc2...", 0.90),
    ]

    # Act
    out = generate_llm_response("What is the official recommendation regarding X from the report?", retrieved)

    # Assert basic structure and expected output
    assert isinstance(out, dict)
    assert 'answer' in out and 'evidence' in out and 'confidence' in out
    assert 'phased rollout strategy' in out['answer']
    assert out['evidence'] == ["doc1.txt:chunk-3", "doc2.txt:chunk-5"]
    assert abs(out['confidence'] - 0.93) < 1e-6


if __name__ == '__main__':
    test_generate_llm_response_returns_expected()
    print('test_llm_only passed')
