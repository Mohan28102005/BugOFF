#!/usr/bin/env python3
import os
import sys

sys.path.append(os.path.dirname(__file__))

from tests.test_llm_only import test_generate_llm_response_returns_expected
from tests.test_pipeline_with_mocks import run as test_pipeline_with_mocks


def main():
    test_generate_llm_response_returns_expected()
    test_pipeline_with_mocks()
    print('\nAll unit tests passed')


if __name__ == '__main__':
    main()
