#!/usr/bin/env bash
set -euo pipefail

# Demo script to run the pipeline using fallback components (no FAISS or transformers required)
cd "$(dirname "$0")/.."

python3 -m pip install --user --upgrade pip
python3 -m pip install --user -r requirements.txt || true

echo "Running the demo (using fallback embeddings/FAISS if not installed)..."
python3 code/main.py

echo "Demo finished"
