from PIL import Image
import os

input_dir = '../screenshots'
output_file = '../screenshots/visualization.gif'

images = []
for fname in sorted(os.listdir(input_dir)):
    if fname.endswith('.png'):
        images.append(Image.open(os.path.join(input_dir, fname)))

if images:
    images[0].save(output_file, save_all=True, append_images=images[1:], optimize=False, duration=200, loop=0)
    print('Saved GIF to', output_file)
else:
    print('No images found in', input_dir)
