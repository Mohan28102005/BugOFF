import os
os.environ['SDL_VIDEODRIVER'] = 'dummy'

from wumpus_world import BangaloreWumpusWorld, GRID_ROWS, GRID_COLS


def make_empty_world(seed=0):
    config = {
        'team_id': 'test',
        'seed': seed,
        'grid_config': {'traffic_lights': 0, 'cows': 0, 'pits': 0}
    }
    world = BangaloreWumpusWorld(config)
    # Reset grid to empty
    for y in range(GRID_ROWS):
        for x in range(GRID_COLS):
            world.grid[y][x]['type'] = 'empty'
            world.grid[y][x]['percepts'] = []
    return world


def test_simple_empty_path():
    world = make_empty_world()
    goal = (2, GRID_ROWS - 1)
    world.grid[goal[1]][goal[0]]['type'] = 'goal'
    world.goal_pos = goal
    path = world.find_path_astar()
    assert path == [(0, GRID_ROWS - 1), (1, GRID_ROWS - 1), goal]
    assert world.planned_path == path


def test_avoid_pit():
    world = make_empty_world()
    # Place pit in direct path
    pit = (1, GRID_ROWS - 1)
    world.grid[pit[1]][pit[0]]['type'] = 'pit'
    # Place goal
    goal = (2, GRID_ROWS - 1)
    world.grid[goal[1]][goal[0]]['type'] = 'goal'
    world.goal_pos = goal

    path = world.find_path_astar()
    expected = [(0, GRID_ROWS - 1), (0, GRID_ROWS - 2), (1, GRID_ROWS - 2), (2, GRID_ROWS - 2), goal]
    assert path == expected
    assert world.planned_path == path


def test_traffic_light_in_path():
    world = make_empty_world()
    tl = (1, GRID_ROWS - 1)
    world.grid[tl[1]][tl[0]]['type'] = 'traffic_light'
    goal = (2, GRID_ROWS - 1)
    world.grid[goal[1]][goal[0]]['type'] = 'goal'
    world.goal_pos = goal

    path = world.find_path_astar()
    # Because traffic lights have high cost, an alternative path via above row may be cheaper
    # so the path may avoid the traffic light. At minimum, ensure a path exists and does not
    # enter a pit or a cow.
    assert path is not None
    assert all(world.grid[y][x]['type'] != 'pit' and world.grid[y][x]['type'] != 'cow' for x, y in path)
    assert world.planned_path == path


def test_forced_traffic_light_path():
    world = make_empty_world()
    tl = (1, GRID_ROWS - 1)
    world.grid[tl[1]][tl[0]]['type'] = 'traffic_light'
    # Block alternative route
    world.grid[0][0]['type'] = 'empty'  # control
    # Block the upper row across (0..2, row-1)
    for x in range(3):
        world.grid[GRID_ROWS - 2][x]['type'] = 'pit'
    goal = (2, GRID_ROWS - 1)
    world.grid[goal[1]][goal[0]]['type'] = 'goal'
    world.goal_pos = goal

    path = world.find_path_astar()
    assert path is not None
    assert tl in path
    assert world.planned_path == path


def test_avoid_cow():
    world = make_empty_world()
    cow = (1, GRID_ROWS - 1)
    world.grid[cow[1]][cow[0]]['type'] = 'cow'
    goal = (2, GRID_ROWS - 1)
    world.grid[goal[1]][goal[0]]['type'] = 'goal'
    world.goal_pos = goal

    path = world.find_path_astar()
    expected = [(0, GRID_ROWS - 1), (0, GRID_ROWS - 2), (1, GRID_ROWS - 2), (2, GRID_ROWS - 2), goal]
    assert path == expected
