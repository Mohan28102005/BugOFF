#!/usr/bin/env python3
import os
os.environ['SDL_VIDEODRIVER'] = 'dummy'

import csv
import time
from pathlib import Path
from PIL import Image
from wumpus_world import BangaloreWumpusWorld, GameRenderer, load_config


def make_gif_from_frames(frames_dir, out_gif, duration=250):
    frames = [Image.open(str(p)) for p in sorted(Path(frames_dir).glob('*.png'))]
    if frames:
        frames[0].save(out_gif, save_all=True, append_images=frames[1:], optimize=False, duration=duration, loop=0)
        return True
    return False


def simulate(num_runs=3, base_seed=100, save_screenshots=True, make_gifs=True, screenshot_frames=8):
    results_dir = Path('simulations')
    results_dir.mkdir(exist_ok=True)
    results_csv = results_dir / 'results.csv'

    headers = ['run', 'seed', 'path_found', 'path_length', 'executed_steps', 'game_won', 'game_over', 'message', 'path_cost']

    with open(results_csv, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(headers)

        for i in range(num_runs):
            seed = base_seed + i
            config = load_config()
            config['seed'] = seed
            world = BangaloreWumpusWorld(config)
            renderer = GameRenderer(world)

            run_dir = results_dir / f'run_{i:03d}'
            frames_dir = run_dir / 'frames'
            if save_screenshots:
                frames_dir.mkdir(parents=True, exist_ok=True)

            # Compute path
            path = world.find_path_astar()
            path_found = path is not None
            path_length = len(path) if path_found else 0
            path_cost = None
            if path_found:
                # compute path cost using same movement_cost logic from find_path_astar
                total_cost = 0
                for (x, y) in path[1:]:  # exclude first cell (start)
                    cell = world.grid[y][x]
                    if cell['type'] == 'traffic_light':
                        total_cost += 5
                    elif cell['type'] in ('cow', 'pit'):
                        total_cost += float('inf')
                    else:
                        total_cost += 1
                path_cost = total_cost

            # Render and save some frames to show overlay
            frames_to_save = screenshot_frames
            frames_saved = 0
            frame_count = 0
            # Render some frames showing overlay before executing
            while frame_count < frames_to_save:
                renderer.render()
                if save_screenshots:
                    fname = frames_dir / f'pre_{frame_count:03d}.png'
                    from pygame import image
                    image.save(renderer.screen, str(fname))
                frame_count += 1
                time.sleep(0.02)

            executed_steps = 0
            # Execute path if found and save a snapshot after each move
            if path_found:
                for x, y in path:
                    world.move_agent(x, y)
                    executed_steps += 1
                    renderer.render()
                    if save_screenshots:
                        fname = frames_dir / f'exec_{executed_steps:03d}.png'
                        from pygame import image
                        image.save(renderer.screen, str(fname))
                    time.sleep(0.01)
                    if world.game_over or world.game_won:
                        break

            # Save final frame
            if save_screenshots:
                final_fname = frames_dir / 'final.png'
                from pygame import image
                image.save(renderer.screen, str(final_fname))

            # Optionally make GIF
            gif_path = ''
            if make_gifs and save_screenshots:
                gif_out = run_dir / 'visualization.gif'
                ok = make_gif_from_frames(frames_dir, gif_out)
                if ok:
                    gif_path = str(gif_out)

            writer.writerow([
                i,
                seed,
                path_found,
                path_length,
                executed_steps,
                world.game_won,
                world.game_over,
                world.message,
                path_cost
            ])

    print('Simulation complete. Results saved to:', results_csv)


if __name__ == '__main__':
    simulate(num_runs=3, base_seed=1234)
