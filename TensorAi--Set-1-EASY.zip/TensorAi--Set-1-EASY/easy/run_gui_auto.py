import os
os.environ['SDL_VIDEODRIVER'] = 'dummy'

import pygame
import time
from wumpus_world import BangaloreWumpusWorld, GameRenderer, load_config


def run_auto(seed=42, steps=200):
    config = load_config()
    world = BangaloreWumpusWorld(config)
    renderer = GameRenderer(world)

    # Simulate pressing SPACE to run A* after a couple frames
    frames = 0
    running = True
    path_executed = False

    while running and frames < steps:
        # simulate event queue
        if frames == 2 and not path_executed:
            print('=== Auto: Executing A* now ===')
            path = world.find_path_astar()
            print('Computed path:', path)
            if path:
                world.execute_path(path)
            path_executed = True

        # Render a frame
        renderer.render()

        # Stop if game ended or path was executed
        if world.game_over or world.game_won:
            running = False

        frames += 1
        time.sleep(0.02)

    print('Final position:', world.agent_pos)
    print('Game over:', world.game_over)
    print('Game won:', world.game_won)
    print('Message:', world.message)


if __name__ == '__main__':
    run_auto()
