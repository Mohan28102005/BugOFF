import os
os.environ['SDL_VIDEODRIVER'] = 'dummy'

import pygame
import time
from pathlib import Path
from wumpus_world import BangaloreWumpusWorld, GameRenderer, load_config


def run_and_save(output_dir='screenshots', frames_to_save=10, seed=42):
    Path(output_dir).mkdir(exist_ok=True)

    config = load_config()
    world = BangaloreWumpusWorld(config)
    renderer = GameRenderer(world)

    # Run for some frames and trigger A* on frame 2
    frames = 0
    path_executed = False

    while frames < frames_to_save:
        if frames == 2 and not path_executed:
            print('=== Auto: Executing A* now (screenshot mode) ===')
            path = world.find_path_astar()
            print('Computed path:', path)
            # We'll render a couple frames showing the overlay then execute
            path_executed = True

        renderer.render()

        # Save current frame
        filename = os.path.join(output_dir, f'frame_{frames:03d}.png')
        pygame.image.save(renderer.screen, filename)

        # Run agent execution after capturing a few overlay frames
        if frames == 5 and path_executed and path:
            world.execute_path(path)

        frames += 1
        time.sleep(0.03)

    # Save a final frame after path execution
    filename = os.path.join(output_dir, f'final_frame.png')
    pygame.image.save(renderer.screen, filename)


if __name__ == '__main__':
    run_and_save()
