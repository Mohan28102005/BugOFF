import os
os.environ['SDL_VIDEODRIVER'] = 'dummy'

from wumpus_world import BangaloreWumpusWorld


def demo():
    config = {
        'team_id': 'demo',
        'seed': 42,
        'grid_config': {'traffic_lights': 2, 'cows': 2, 'pits': 3}
    }
    world = BangaloreWumpusWorld(config)

    print('Agent start:', world.agent_start)
    print('Goal position:', world.goal_pos)
    print('Grid types:')
    for y in range(len(world.grid)):
        print([world.grid[y][x]['type'][0] for x in range(len(world.grid[0]))])

    path = world.find_path_astar()
    print('Found path:', path)
    if path is not None:
        world.execute_path(path)
    print('Final position:', world.agent_pos)
    print('Game over:', world.game_over)
    print('Game won:', world.game_won)
    print('Message:', world.message)


if __name__ == '__main__':
    demo()
