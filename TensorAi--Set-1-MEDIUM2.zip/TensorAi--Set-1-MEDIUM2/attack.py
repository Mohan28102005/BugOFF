#!/usr/bin/env python3
"""
attack.py
Simple FGSM attack script to perturb an input image to mislead a Keras model.

Usage:
  python attack.py --model path/to/model.h5 --image path/to/image.png [--epsilon 0.1] [--target 3]

If `flag_data.json` exists, the script will use it to decode predicted classes into a secret string.
"""
import argparse
import json
import os
from pathlib import Path

import numpy as np
from PIL import Image

try:
    try:
        import tensorflow as tf
        from tensorflow.keras.models import load_model
    except Exception as e:
        print("Error: TensorFlow import failed. Please install the dependencies listed in requirements.txt: `pip install -r requirements.txt`")
        raise
except Exception as e:
    print("Error: TensorFlow import failed. Please install the dependencies listed in requirements.txt: `pip install -r requirements.txt`")
    raise


def load_class_names(path):
    if not os.path.exists(path):
        return None
    with open(path, 'r') as f:
        lines = [l.strip() for l in f if l.strip()]
    classes = {}
    for line in lines:
        # lines like `0: T-shirt/top`
        if ':' in line:
            idx, name = line.split(':', 1)
            classes[int(idx.strip())] = name.strip()
    return classes


def load_image(path, target_size=(28, 28)):
    im = Image.open(path).convert('L').resize(target_size)
    arr = np.asarray(im).astype('float32') / 255.0
    # Model expects (1, 28,28,1)
    arr = arr.reshape(1, target_size[0], target_size[1], 1)
    return arr


def save_image(arr, path):
    arr = np.clip(arr, 0, 1)
    arr = (arr * 255).astype('uint8')
    if arr.ndim == 4:
        arr = arr[0, :, :, 0]
    Image.fromarray(arr).save(path)


def fgsm_attack(model, x, y_true=None, epsilon=0.1, targeted=False, target_class=None):
    # x: np array (1,H,W,1)
    x_tensor = tf.convert_to_tensor(x)
    x_tensor = tf.cast(x_tensor, tf.float32)

    with tf.GradientTape() as tape:
        tape.watch(x_tensor)
        preds = model(x_tensor, training=False)
        if targeted:
            assert target_class is not None, "target_class must be provided for targeted FGSM"
            loss = tf.keras.losses.sparse_categorical_crossentropy([target_class], preds)
        else:
            if y_true is None:
                # choose current top class as y_true
                y_true = tf.argmax(preds, axis=1)
            loss = tf.keras.losses.sparse_categorical_crossentropy(y_true, preds)
    gradient = tape.gradient(loss, x_tensor)
    signed_grad = tf.sign(gradient)
    if targeted:
        # move input in the direction that increases the target class probability
        adv_x = x_tensor - epsilon * signed_grad
    else:
        adv_x = x_tensor + epsilon * signed_grad
    return adv_x.numpy()


def pgd_attack(model, x, y_true=None, epsilon=0.1, steps=10, targeted=False, target_class=None):
    # Iterative FGSM (projected gradient descent)
    alpha = epsilon / steps
    adv_x = x.copy()
    for i in range(steps):
        adv_x = fgsm_attack(model, adv_x, y_true=y_true, epsilon=alpha, targeted=targeted, target_class=target_class)
        # project
        adv_x = np.clip(adv_x, x - epsilon, x + epsilon)
        adv_x = np.clip(adv_x, 0.0, 1.0)
    return adv_x


def decode_with_flag_data(preds, flag_data_path):
    # loads json mapping from something -> characters
    if not os.path.exists(flag_data_path):
        return None
    with open(flag_data_path, 'r') as f:
        data = json.load(f)
    # Support simple mapping from class indices to characters
    if isinstance(data, dict):
        try:
            return ''.join([data[str(int(p))] for p in preds])
        except Exception:
            pass
    return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', required=True)
    parser.add_argument('--image', required=False)
    parser.add_argument('--image_dir', required=False, help='Directory to read images from to produce a sequence of outputs')
    parser.add_argument('--epsilon', type=float, default=0.1)
    parser.add_argument('--steps', type=int, default=1, help='Number of FGSM steps (if >1, runs PGD)')
    parser.add_argument('--target', type=int, default=None)
    parser.add_argument('--target_flag', type=str, default=None, help='If present and flag_data.json exists and maps classes to characters, target each image to the class that corresponds to each character of this string')
    parser.add_argument('--reveal', action='store_true', help='Create a reveal image overlaying decoded secret and try to open it in the system viewer')
    parser.add_argument('--output', default='adv.png')
    parser.add_argument('--bruteforce', action='store_true', help='Try forcing each image to all possible target classes (0-9) and show which succeed')
    args = parser.parse_args()

    model_path = Path(args.model)
    if not model_path.exists():
        raise SystemExit(f"Model path does not exist: {model_path}")

    # Attempt to load model using tf.keras; fallback to standalone keras if needed
    try:
        model = load_model(str(model_path))
        print('Loaded model using tensorflow.keras')
    except TypeError as e:
        print('TensorFlow Keras failed to deserialize model with TypeError:', e)
        # Try to patch the model_config in the HDF5 to replace `batch_shape` with `batch_input_shape` and rebuild
        try:
            import h5py
            import json as _json
            with h5py.File(str(model_path), 'r') as f:
                if 'model_config' in f.attrs:
                    raw = f.attrs['model_config']
                    if isinstance(raw, bytes):
                        raw = raw.decode('utf-8')
                    model_cfg = _json.loads(raw)
                else:
                    raise RuntimeError('No model_config in h5')
            # replace batch_shape occurrences
            def fix_layer(layer):
                cfg = layer.get('config', {})
                if 'batch_shape' in cfg:
                    cfg['batch_input_shape'] = cfg.pop('batch_shape')
                # some nested layers
                for k, v in layer.items():
                    if isinstance(v, dict) and 'config' in v:
                        fix_layer(v)
            for layer in model_cfg.get('config', {}).get('layers', []):
                fix_layer(layer)
            # rebuild model from modified config using a conservative parser
            def rebuild_from_cfg(cfg):
                from tensorflow.keras import layers, models
                layers_list = []
                input_shape = None
                for layer in cfg.get('config', {}).get('layers', []):
                    cls = layer.get('class_name')
                    lcfg = layer.get('config', {})
                    name = lcfg.get('name')
                    if cls == 'InputLayer':
                        # batch_shape might be present
                        bshape = lcfg.get('batch_shape') or lcfg.get('batch_input_shape')
                        if bshape is not None:
                            input_shape = tuple(bshape[1:])
                    elif cls == 'Conv2D':
                        filters = lcfg.get('filters')
                        kernel_size = tuple(lcfg.get('kernel_size'))
                        activation = lcfg.get('activation')
                        layers_list.append(layers.Conv2D(filters, kernel_size, activation=activation, name=name))
                    elif cls == 'BatchNormalization':
                        layers_list.append(layers.BatchNormalization(name=name))
                    elif cls == 'MaxPooling2D':
                        pool_size = tuple(lcfg.get('pool_size', (2,2)))
                        layers_list.append(layers.MaxPooling2D(pool_size=pool_size, name=name))
                    elif cls == 'Flatten':
                        layers_list.append(layers.Flatten(name=name))
                    elif cls == 'Dense':
                        units = lcfg.get('units')
                        activation = lcfg.get('activation')
                        layers_list.append(layers.Dense(units, activation=activation, name=name))
                    elif cls == 'Dropout':
                        rate = lcfg.get('rate')
                        layers_list.append(layers.Dropout(rate, name=name))
                    else:
                        # Ignore unsupported classes (e.g., Activation layers, etc.) or try to be permissive
                        pass
                model_builder = models.Sequential(name=cfg.get('config', {}).get('name', 'patched_model'))
                if input_shape is not None:
                    model_builder.add(layers.InputLayer(input_shape=input_shape, name='input_layer'))
                for l in layers_list:
                    model_builder.add(l)
                return model_builder

            model = rebuild_from_cfg(model_cfg)
            # load weights by name
            model.load_weights(str(model_path), by_name=True)
            print('Loaded model by patching model_config and rebuilding model (by_name weights)')
        except Exception as e2:
            print('Failed to rebuild model from patched model_config:', e2)
            # try standalone keras as last resort
            try:
                import keras as standalone_keras
                model = standalone_keras.models.load_model(str(model_path))
                print('Loaded model using standalone keras')
            except Exception as e3:
                print('Failed to load model with standalone keras:', e3)
                raise
    except Exception:
        raise
    classes = load_class_names('class_names (1).txt')
    # find image
    image_path = None
    if args.image and Path(args.image).exists():
        image_path = Path(args.image)
    else:
        if args.image_dir and Path(args.image_dir).exists():
            # We'll pick up the directory listing later and process all images
            image_path = None
        else:
            # fallback to search images folder for any png
            for p in Path('.').rglob('*.png'):
                if 'Flag' in p.name or 'flag' in p.name:
                    image_path = p
                    break
        if image_path is None:
            for p in Path('.').rglob('images/*.png'):
                image_path = p
                break
    if image_path is None:
        print('No image found; please provide --image Flag_image.png')
        return

    def process_single(img_path, idx=None):
        x = load_image(str(img_path))
        preds = model.predict(x)
        orig_pred = np.argmax(preds, axis=1)[0]
        print(f"[{idx}] Original prediction: {orig_pred} - {classes.get(orig_pred, '')} (image: {img_path})")

        if args.steps and args.steps > 1:
            adv_x = pgd_attack(model, x, y_true=None, epsilon=args.epsilon, steps=args.steps, targeted=(args.target is not None), target_class=args.target)
        else:
            adv_x = fgsm_attack(model, x, y_true=None, epsilon=args.epsilon, targeted=(args.target is not None), target_class=args.target)
        preds_adv = model.predict(adv_x)
        adv_pred = np.argmax(preds_adv, axis=1)[0]
        print(f"[{idx}] Adversarial prediction: {adv_pred} - {classes.get(adv_pred, '')}")

        # save
        out_name = f"adv_{idx}.png" if idx is not None else args.output
        save_image(adv_x, out_name)
        save_image(x, f'orig_{idx}.png' if idx is not None else 'orig_input.png')
        diff = (adv_x - x) * 10 + 0.5
        save_image(diff, f'diff_{idx}.png' if idx is not None else 'diff.png')
        return adv_pred

    def brute_force_targets(img_path, idx=None):
        results = {}
        for t in range(10):
            x = load_image(str(img_path))
            # targeted PGD
            adv_x = pgd_attack(model, x, y_true=None, epsilon=args.epsilon, steps=args.steps or 10, targeted=True, target_class=t)
            preds_adv = model.predict(adv_x)
            adv_pred = int(np.argmax(preds_adv, axis=1)[0])
            results[t] = (adv_pred == t)
        print(f"Bruteforce results for [{idx}] {img_path}: {results}")
        return results

    if args.image_dir and Path(args.image_dir).exists():
        img_paths = sorted(Path(args.image_dir).rglob('*.png'))
        predictions = []
        bruteforce_results = {}
        for i, p in enumerate(img_paths):
            pred = process_single(p, idx=i)
            predictions.append(int(pred))
            if args.bruteforce:
                bruteforce_results[str(p)] = brute_force_targets(p, idx=i)
        preds_list = predictions
        if args.bruteforce:
            with open('bruteforce_results.json', 'w') as f:
                json.dump(bruteforce_results, f, indent=2)
        # Save predictions to a json file for programmatic decoding
        pred_entries = []
        for i,p in enumerate(img_paths):
            pred_entries.append({'image': str(p), 'adv_pred': int(predictions[i])})
        with open('predictions.json', 'w') as f:
            json.dump(pred_entries, f, indent=2)
    else:
        x = load_image(str(image_path))
        preds = model.predict(x)
        orig_pred = np.argmax(preds, axis=1)[0]
        print(f"Original prediction: {orig_pred} - {classes.get(orig_pred, '')}")
        if args.steps and args.steps > 1:
            adv_x = pgd_attack(model, x, y_true=None, epsilon=args.epsilon, steps=args.steps, targeted=(args.target is not None), target_class=args.target)
        else:
            adv_x = fgsm_attack(model, x, y_true=None, epsilon=args.epsilon, targeted=(args.target is not None), target_class=args.target)
        preds_adv = model.predict(adv_x)
        adv_pred = np.argmax(preds_adv, axis=1)[0]
        print(f"Adversarial prediction: {adv_pred} - {classes.get(adv_pred, '')}")
        save_image(x, 'orig_input.png')
        save_image(adv_x, args.output)
        diff = (adv_x - x) * 10 + 0.5
        save_image(diff, 'diff.png')
        preds_list = [int(adv_pred)]
    # try decode with flag_data.json
    flag = None
    if Path('flag_data.json').exists():
        flag = decode_with_flag_data(preds_list, 'flag_data.json')
        if flag:
            print('Decoded secret from flag_data.json:', flag)
    if flag is None:
        print('No `flag_data.json` present or no decoding available; provide it alongside the attack to decode automatically.')

    # If user requested to target a known flag string using mapping
    if args.target_flag and Path('flag_data.json').exists():
        with open('flag_data.json','r') as f:
            map_data = json.load(f)
        # invert mapping
        inv = {v: int(k) for k,v in map_data.items()}
        target_str = args.target_flag
        img_paths = []
        if args.image_dir and Path(args.image_dir).exists():
            img_paths = sorted(Path(args.image_dir).rglob('*.png'))
        elif image_path is not None:
            img_paths = [image_path]
        else:
            img_paths = []
        if len(img_paths) < len(target_str):
            print(f"Not enough images ({len(img_paths)}) to map to flag string length ({len(target_str)}).")
        else:
            print('Targeting flag string using mapping...')
            results = []
            for i,ch in enumerate(target_str):
                if ch not in inv:
                    print(f"Character {ch} not mapped in flag_data.json; skipping.")
                    results.append(False)
                    continue
                target_class = inv[ch]
                img = img_paths[i]
                x = load_image(str(img))
                adv_x = pgd_attack(model, x, y_true=None, epsilon=args.epsilon, steps=args.steps or 10, targeted=True, target_class=target_class)
                preds_adv = model.predict(adv_x)
                adv_pred = int(np.argmax(preds_adv, axis=1)[0])
                save_image(adv_x, f'targeted_adv_{i}.png')
                save_image(x, f'targeted_orig_{i}.png')
                results.append(adv_pred == target_class)
                print(f"[{i}] image {img} targeted to class {target_class} -> achieved {adv_pred}")
            print('Targeted flag attempt results:', results)

    # Create a reveal image if requested and we decoded a flag
    if args.reveal and flag:
        from PIL import ImageDraw, ImageFont
        # make a canvas: if image_dir, create a composite; otherwise use last adv image
        canvas = None
        if args.image_dir and Path(args.image_dir).exists():
            img_paths = sorted(Path(args.image_dir).rglob('*.png'))
            adv_images = []
            for i,p in enumerate(img_paths):
                adv_path = Path(f'adv_{i}.png')
                if adv_path.exists():
                    adv_images.append(Image.open(adv_path).convert('RGBA'))
            if len(adv_images) > 0:
                widths, heights = zip(*(i.size for i in adv_images))
                total_w = sum(widths)
                max_h = max(heights)
                canvas = Image.new('RGBA', (total_w, max_h + 80), (255,255,255,255))
                x_offset = 0
                for im in adv_images:
                    canvas.paste(im, (x_offset, 0))
                    x_offset += im.size[0]
        else:
            # use last generated `adv.png` or `adv_0.png`
            adv_path = Path(args.output) if Path(args.output).exists() else Path('adv_0.png')
            if adv_path.exists():
                canvas = Image.open(adv_path).convert('RGBA')
                # expand canvas to add space for text
                w,h = canvas.size
                new_h = h + 80
                new_canvas = Image.new('RGBA', (w, new_h), (255,255,255,255))
                new_canvas.paste(canvas, (0,0))
                canvas = new_canvas
        if canvas is not None:
            draw = ImageDraw.Draw(canvas)
            try:
                # Use default truetype font if available
                font = ImageFont.truetype('DejaVuSans-Bold.ttf', 40)
            except Exception:
                font = ImageFont.load_default()
            text = str(flag)
            # center text
            tw, th = draw.textsize(text, font=font)
            canvas_w, canvas_h = canvas.size
            draw.text(((canvas_w - tw) / 2, canvas_h - 65), text, fill=(255,0,0), font=font)
            reveal_path = Path('reveal.png')
            canvas.convert('RGB').save(str(reveal_path))
            print('Saved reveal image to', str(reveal_path))
            # Try to open with default viewer on Linux
            try:
                import subprocess, sys
                if sys.platform.startswith('linux'):
                    subprocess.Popen(['xdg-open', str(reveal_path)])
                elif sys.platform == 'darwin':
                    subprocess.Popen(['open', str(reveal_path)])
                else:
                    # fallback: open in Python webbrowser
                    import webbrowser
                    webbrowser.open(str(reveal_path))
            except Exception as e:
                print('Could not open reveal image automatically:', e)


if __name__ == '__main__':
    main()
