# FGSM Attack PoC

This workspace contains a small proof-of-concept script to run a gradient-based FGSM adversarial attack on a provided Keras model and a secret image. The attack saves the generated adversarial image, shows the before/after predictions, and optionally decodes the predicted classes via a `flag_data.json` mapping.

Usage:
1. Install dependencies:
```bash
python -m pip install -r requirements.txt
```
2. Place your model here (e.g., `fashion_classifier (1).h5`), and place your secret image `Flag_image.png` (or use the `--image` option to specify another image). For multi-part flags, place all images into a directory and pass `--image_dir`.
3. If you have a mapping file `flag_data.json`, place it in the project root to enable automated decoding. For multi-character secrets, put the images in a directory and pass `--image_dir path/to/images` (images will be sorted by filename and processed in order).
4. Run the script:
```bash
python attack.py --model 'fashion_classifier (1).h5' --image path/to/Flag_image.png --epsilon 0.1
# or run against a whole directory (useful for multi-part flags):
python attack.py --model 'fashion_classifier (1).h5' --image_dir extracted_images/images --epsilon 0.1
```

Notes:
- The FGSM attack has a tunable `epsilon` parameter — try values like 0.01–0.25.
- If `flag_data.json` is present and maps predicted classes to characters, the script will attempt to decode the secret automatically.
- Use `--steps N` to run iterative PGD attack (N steps) rather than single-step FGSM. Use `--bruteforce` to try to force each image into all possible classes and inspect which are achievable. Use `--target_flag "FLAG"` with a `flag_data.json` mapping to attempt to build the flag by targeting specific classes per image.
 - Use `--steps N` to run iterative PGD attack (N steps) rather than single-step FGSM. Use `--bruteforce` to try to force each image into all possible classes and inspect which are achievable. Use `--target_flag "FLAG"` with a `flag_data.json` mapping to attempt to build the flag by targeting specific classes per image.
 - Use `--reveal` to generate a `reveal.png` overlaying the decoded secret onto the resulting adversarial image(s) and attempt to open it using your OS viewer (`xdg-open` on Linux).
